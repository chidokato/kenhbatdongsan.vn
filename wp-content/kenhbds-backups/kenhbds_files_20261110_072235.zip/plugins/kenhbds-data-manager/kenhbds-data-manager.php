<?php
/**
 * Plugin Name: Kênh Bất Động Sản - Quản lý Dữ liệu & Backup Toàn diện (Core)
 * Plugin URI: https://kenhbatdongsan.vn
 * Description: Hệ thống lõi quản lý Dữ liệu Dự án (Mô hình B), Giỏ hàng xác thực & Phễu SEO (Mô hình D), CRM Khách hàng, Xuất/Nhập Excel-JSON và Sao lưu/Tối ưu Database tự động cho kenhbatdongsan.vn.
 * Version: 1.0.0
 * Author: KenhBatDongSan.vn
 * Text Domain: kenhbds-data-manager
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'KBDS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'KBDS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once KBDS_PLUGIN_DIR . 'includes/class-kbds-post-types.php';
require_once KBDS_PLUGIN_DIR . 'includes/class-kbds-backup-manager.php';
require_once KBDS_PLUGIN_DIR . 'includes/class-kbds-shortcodes.php';

// Khởi chạy các phân hệ
KBDS_Post_Types::init();
KBDS_Backup_Manager::init();
KBDS_Shortcodes::init();

/**
 * Kích hoạt Plugin: Khởi tạo Danh mục chuẩn, Lịch Backup tự động và Rewrite Rules
 */
register_activation_hook( __FILE__, 'kbds_activate_plugin' );

function kbds_activate_plugin() {
	KBDS_Post_Types::seed_default_terms();
	KBDS_Backup_Manager::get_backup_dir();

	if ( ! wp_next_scheduled( KBDS_Backup_Manager::CRON_HOOK ) ) {
		wp_schedule_event( time() + 300, 'daily', KBDS_Backup_Manager::CRON_HOOK );
	}

	flush_rewrite_rules();
}
