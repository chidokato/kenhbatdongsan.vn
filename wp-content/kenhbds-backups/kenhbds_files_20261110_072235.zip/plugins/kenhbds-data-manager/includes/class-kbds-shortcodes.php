<?php
/**
 * Bộ Shortcode Chuyên dụng cho Mô hình B + D (kenhbatdongsan.vn)
 * - [kbds_project_overview]   : Bảng tổng quan dự án + Đánh giá chuyên gia
 * - [kbds_project_listings]   : Giỏ hàng các căn đang bán thuộc dự án
 * - [kbds_loan_calculator]    : Công cụ tính lãi vay mua nhà trả góp
 * - [kbds_lead_form]          : Form nhận bảng giá / ký gửi lưu thẳng vào CRM Database
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class KBDS_Shortcodes {

	public static function init() {
		add_shortcode( 'kbds_project_overview', array( __CLASS__, 'shortcode_project_overview' ) );
		add_shortcode( 'kbds_project_listings', array( __CLASS__, 'shortcode_project_listings' ) );
		add_shortcode( 'kbds_loan_calculator', array( __CLASS__, 'shortcode_loan_calculator' ) );
		add_shortcode( 'kbds_lead_form', array( __CLASS__, 'shortcode_lead_form' ) );

		// Tự động gắn thông tin tổng quan & giỏ hàng vào cuối trang chi tiết Dự án nếu chưa chèn shortcode
		add_filter( 'the_content', array( __CLASS__, 'auto_append_project_sections' ) );
	}

	/**
	 * 1. Bảng Tổng quan Hồ sơ Dự án
	 */
	public static function shortcode_project_overview( $atts ) {
		$atts = shortcode_atts( array( 'id' => get_the_ID() ), $atts );
		$pid  = (int) $atts['id'];
		if ( ! $pid ) {
			return '';
		}

		$code     = get_post_meta( $pid, '_kbds_project_code', true );
		$price    = get_post_meta( $pid, '_kbds_price_from', true );
		$address  = get_post_meta( $pid, '_kbds_address', true );
		$area     = get_post_meta( $pid, '_kbds_total_area', true );
		$scale    = get_post_meta( $pid, '_kbds_scale', true );
		$legal    = get_post_meta( $pid, '_kbds_legal_status', true );
		$handover = get_post_meta( $pid, '_kbds_handover_time', true );
		$bank     = get_post_meta( $pid, '_kbds_bank_support', true );
		$score    = get_post_meta( $pid, '_kbds_review_score', true );
		$pros     = get_post_meta( $pid, '_kbds_pros_cons', true );

		$cdt_terms    = wp_get_post_terms( $pid, 'chu_dau_tu', array( 'fields' => 'names' ) );
		$status_terms = wp_get_post_terms( $pid, 'trang_thai_du_an', array( 'fields' => 'names' ) );

		ob_start();
		?>
		<div class="kbds-overview-card" style="background:#fff;border:1px solid #e2e8f0;border-radius:10px;padding:24px;margin:24px 0;box-shadow:0 2px 8px rgba(15,62,109,0.06);">
			<div style="display:flex;justify-content:space-between;align-items:center;border-bottom:2px solid #0f3e6d;padding-bottom:12px;margin-bottom:16px;flex-wrap:wrap;gap:10px;">
				<h3 style="margin:0;color:#0f3e6d;font-size:20px;">🏢 Thông tin Tổng quan Dự án <?php echo esc_html( get_the_title( $pid ) ); ?></h3>
				<?php if ( $score ) : ?>
					<span style="background:#0f3e6d;color:#fff;padding:6px 14px;border-radius:6px;font-weight:700;font-size:14px;">
						⭐ Đánh giá Kênh BĐS: <?php echo esc_html( $score ); ?>/10
					</span>
				<?php endif; ?>
			</div>

			<table style="width:100%;border-collapse:collapse;font-size:15px;">
				<tbody>
					<?php if ( $price ) : ?>
					<tr style="border-bottom:1px solid #f1f5f9;">
						<td style="padding:10px 8px;font-weight:600;color:#475569;width:35%;">💰 Giá bán tham khảo:</td>
						<td style="padding:10px 8px;font-weight:700;color:#e53935;font-size:17px;"><?php echo esc_html( $price ); ?></td>
					</tr>
					<?php endif; ?>
					<?php if ( ! empty( $status_terms ) ) : ?>
					<tr style="border-bottom:1px solid #f1f5f9;">
						<td style="padding:10px 8px;font-weight:600;color:#475569;">📌 Trạng thái:</td>
						<td style="padding:10px 8px;"><span style="background:#e8f5e9;color:#1b8a4b;padding:3px 10px;border-radius:4px;font-weight:600;"><?php echo esc_html( implode( ', ', $status_terms ) ); ?></span></td>
					</tr>
					<?php endif; ?>
					<?php if ( ! empty( $cdt_terms ) ) : ?>
					<tr style="border-bottom:1px solid #f1f5f9;">
						<td style="padding:10px 8px;font-weight:600;color:#475569;">🏛️ Chủ đầu tư:</td>
						<td style="padding:10px 8px;font-weight:600;"><?php echo esc_html( implode( ', ', $cdt_terms ) ); ?></td>
					</tr>
					<?php endif; ?>
					<?php if ( $address ) : ?>
					<tr style="border-bottom:1px solid #f1f5f9;">
						<td style="padding:10px 8px;font-weight:600;color:#475569;">📍 Vị trí dự án:</td>
						<td style="padding:10px 8px;"><?php echo esc_html( $address ); ?></td>
					</tr>
					<?php endif; ?>
					<?php if ( $area ) : ?>
					<tr style="border-bottom:1px solid #f1f5f9;">
						<td style="padding:10px 8px;font-weight:600;color:#475569;">📐 Quy mô diện tích:</td>
						<td style="padding:10px 8px;"><?php echo esc_html( $area ); ?></td>
					</tr>
					<?php endif; ?>
					<?php if ( $scale ) : ?>
					<tr style="border-bottom:1px solid #f1f5f9;">
						<td style="padding:10px 8px;font-weight:600;color:#475569;">🏙️ Quy mô sản phẩm:</td>
						<td style="padding:10px 8px;"><?php echo esc_html( $scale ); ?></td>
					</tr>
					<?php endif; ?>
					<?php if ( $legal ) : ?>
					<tr style="border-bottom:1px solid #f1f5f9;">
						<td style="padding:10px 8px;font-weight:600;color:#475569;">⚖️ Pháp lý:</td>
						<td style="padding:10px 8px;"><?php echo esc_html( $legal ); ?></td>
					</tr>
					<?php endif; ?>
					<?php if ( $handover ) : ?>
					<tr style="border-bottom:1px solid #f1f5f9;">
						<td style="padding:10px 8px;font-weight:600;color:#475569;">🔑 Thời gian bàn giao:</td>
						<td style="padding:10px 8px;"><?php echo esc_html( $handover ); ?></td>
					</tr>
					<?php endif; ?>
					<?php if ( $bank ) : ?>
					<tr>
						<td style="padding:10px 8px;font-weight:600;color:#475569;">🏦 Hỗ trợ tài chính:</td>
						<td style="padding:10px 8px;"><?php echo esc_html( $bank ); ?></td>
					</tr>
					<?php endif; ?>
				</tbody>
			</table>

			<?php if ( $pros ) : ?>
				<div style="background:#f8fafc;border-left:4px solid #d99b26;padding:14px 18px;margin-top:16px;border-radius:4px;">
					<strong style="color:#0f3e6d;display:block;margin-bottom:6px;">💡 Nhận định nhanh từ Chuyên gia Kênh BĐS:</strong>
					<div style="white-space:pre-line;line-height:1.6;color:#334155;"><?php echo esc_html( $pros ); ?></div>
				</div>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * 2. Hiển thị Giỏ hàng các sản phẩm đang bán của Dự án
	 */
	public static function shortcode_project_listings( $atts ) {
		$atts = shortcode_atts( array(
			'project_id' => get_the_ID(),
			'limit'      => 6,
		), $atts );

		$args = array(
			'post_type'      => 'bat_dong_san',
			'posts_per_page' => (int) $atts['limit'],
			'post_status'    => 'publish',
		);

		if ( ! empty( $atts['project_id'] ) && 'du_an' === get_post_type( (int) $atts['project_id'] ) ) {
			$args['meta_query'] = array(
				array(
					'key'   => '_kbds_parent_project_id',
					'value' => (int) $atts['project_id'],
				),
			);
		}

		$listings = get_posts( $args );
		if ( empty( $listings ) ) {
			return '';
		}

		ob_start();
		?>
		<div class="kbds-listings-section" style="margin:28px 0;">
			<h3 style="color:#0f3e6d;border-bottom:2px solid #0f3e6d;padding-bottom:10px;">
				🏠 Giỏ hàng Chuyển nhượng & Suất đẹp Đang bán (Đã xác thực)
			</h3>
			<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:18px;margin-top:16px;">
				<?php foreach ( $listings as $item ) : ?>
					<?php
					$code     = get_post_meta( $item->ID, '_kbds_listing_code', true );
					$price    = get_post_meta( $item->ID, '_kbds_listing_price', true );
					$area     = get_post_meta( $item->ID, '_kbds_area_m2', true );
					$beds     = get_post_meta( $item->ID, '_kbds_bedrooms', true );
					$dir      = get_post_meta( $item->ID, '_kbds_direction', true );
					$verified = get_post_meta( $item->ID, '_kbds_is_verified', true );
					?>
					<div style="background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:18px;box-shadow:0 1px 4px rgba(0,0,0,0.05);">
						<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
							<span style="font-size:12px;color:#64748b;font-weight:600;">Mã: <?php echo esc_html( $code ?: '#' . $item->ID ); ?></span>
							<?php if ( '1' === $verified ) : ?>
								<span style="background:#e8f5e9;color:#1b8a4b;font-size:11px;font-weight:700;padding:2px 8px;border-radius:4px;">✔ Đã xác thực</span>
							<?php endif; ?>
						</div>
						<h4 style="margin:0 0 10px;font-size:16px;"><a href="<?php echo esc_url( get_permalink( $item->ID ) ); ?>" style="color:#0f3e6d;text-decoration:none;"><?php echo esc_html( $item->post_title ); ?></a></h4>
						<div style="font-size:18px;font-weight:700;color:#e53935;margin-bottom:10px;"><?php echo esc_html( $price ?: 'Giá liên hệ' ); ?></div>
						<div style="font-size:13px;color:#475569;display:flex;gap:12px;flex-wrap:wrap;">
							<?php if ( $area ) : ?><span>📐 <?php echo esc_html( $area ); ?> m²</span><?php endif; ?>
							<?php if ( $beds ) : ?><span>🛏️ <?php echo esc_html( $beds ); ?> PN</span><?php endif; ?>
							<?php if ( $dir ) : ?><span>🧭 <?php echo esc_html( $dir ); ?></span><?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * 3. Công cụ Tính khoản vay mua nhà trả góp (Interactive Calculator)
	 */
	public static function shortcode_loan_calculator() {
		ob_start();
		?>
		<div class="kbds-loan-calc" style="background:#f8fafc;border:1px solid #cbd5e1;border-radius:10px;padding:24px;margin:24px 0;">
			<h3 style="margin-top:0;color:#0f3e6d;">🧮 Công cụ Tính Lãi Vay Mua Bất Động Sản Hàng Tháng</h3>
			<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;">
				<div>
					<label style="font-weight:600;font-size:14px;">Giá trị BĐS (Tỷ VNĐ):</label>
					<input type="number" id="kbds_calc_price" value="3.5" step="0.1" style="width:100%;padding:8px;margin-top:4px;" oninput="kbdsCalculateLoan()" />
				</div>
				<div>
					<label style="font-weight:600;font-size:14px;">Tỷ lệ vay (%):</label>
					<input type="number" id="kbds_calc_ratio" value="70" min="10" max="90" style="width:100%;padding:8px;margin-top:4px;" oninput="kbdsCalculateLoan()" />
				</div>
				<div>
					<label style="font-weight:600;font-size:14px;">Thời hạn vay (Năm):</label>
					<input type="number" id="kbds_calc_years" value="20" min="1" max="35" style="width:100%;padding:8px;margin-top:4px;" oninput="kbdsCalculateLoan()" />
				</div>
				<div>
					<label style="font-weight:600;font-size:14px;">Lãi suất (%/năm):</label>
					<input type="number" id="kbds_calc_rate" value="7.5" step="0.1" style="width:100%;padding:8px;margin-top:4px;" oninput="kbdsCalculateLoan()" />
				</div>
			</div>
			<div id="kbds_calc_result" style="background:#fff;padding:16px;border-radius:8px;margin-top:16px;display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;border-left:4px solid #0f3e6d;">
				<div><span style="color:#64748b;font-size:13px;">Vốn tự có cần chuẩn bị:</span><br/><strong id="kbds_res_equity" style="font-size:18px;color:#0f3e6d;">1.05 tỷ</strong></div>
				<div><span style="color:#64748b;font-size:13px;">Số tiền vay ngân hàng:</span><br/><strong id="kbds_res_loan" style="font-size:18px;color:#1b8a4b;">2.45 tỷ</strong></div>
				<div><span style="color:#64748b;font-size:13px;">Gốc + Lãi tháng cao nhất:</span><br/><strong id="kbds_res_monthly" style="font-size:18px;color:#e53935;">25.52 triệu/tháng</strong></div>
			</div>
			<script>
			function kbdsCalculateLoan() {
				var price = parseFloat(document.getElementById('kbds_calc_price').value) || 0;
				var ratio = parseFloat(document.getElementById('kbds_calc_ratio').value) || 0;
				var years = parseFloat(document.getElementById('kbds_calc_years').value) || 1;
				var rate  = parseFloat(document.getElementById('kbds_calc_rate').value) || 0;

				var loanBillion = price * (ratio / 100);
				var equityBillion = price - loanBillion;
				var months = years * 12;
				var principalMillion = (loanBillion * 1000) / months;
				var firstInterestMillion = (loanBillion * 1000) * (rate / 100 / 12);
				var firstMonthTotal = principalMillion + firstInterestMillion;

				document.getElementById('kbds_res_equity').innerText = equityBillion.toFixed(2) + ' tỷ';
				document.getElementById('kbds_res_loan').innerText = loanBillion.toFixed(2) + ' tỷ';
				document.getElementById('kbds_res_monthly').innerText = firstMonthTotal.toFixed(2) + ' triệu/tháng';
			}
			</script>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * 4. Form Đăng ký Nhận Bảng giá / Pháp lý lưu thẳng vào CRM Database
	 */
	public static function shortcode_lead_form( $atts ) {
		$atts = shortcode_atts( array(
			'title'   => '📥 Tải Trọn Bộ Bảng Giá, Mặt Bằng & Pháp Lý Mới Nhất',
			'project' => get_the_title(),
		), $atts );

		$submitted = false;
		if ( isset( $_POST['kbds_lead_submit'] ) && isset( $_POST['kbds_lead_nonce'] ) ) {
			if ( wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kbds_lead_nonce'] ) ), 'kbds_submit_lead' ) ) {
				$name    = sanitize_text_field( wp_unslash( $_POST['kbds_name'] ?? '' ) );
				$phone   = sanitize_text_field( wp_unslash( $_POST['kbds_phone'] ?? '' ) );
				$email   = sanitize_email( wp_unslash( $_POST['kbds_email'] ?? '' ) );
				$project = sanitize_text_field( wp_unslash( $_POST['kbds_project'] ?? '' ) );
				$demand  = sanitize_textarea_field( wp_unslash( $_POST['kbds_demand'] ?? '' ) );

				if ( $name && $phone ) {
					$lead_id = wp_insert_post( array(
						'post_type'   => 'bds_lead',
						'post_status' => 'publish',
						'post_title'  => $name . ' - ' . $phone,
					) );
					if ( $lead_id && ! is_wp_error( $lead_id ) ) {
						update_post_meta( $lead_id, '_kbds_lead_phone', $phone );
						update_post_meta( $lead_id, '_kbds_lead_email', $email );
						update_post_meta( $lead_id, '_kbds_lead_project', $project );
						update_post_meta( $lead_id, '_kbds_lead_demand', $demand );
						update_post_meta( $lead_id, '_kbds_lead_status', 'new' );
						$submitted = true;
					}
				}
			}
		}

		ob_start();
		?>
		<div class="kbds-lead-box" style="background:linear-gradient(135deg,#0f3e6d 0%,#16538f 100%);color:#fff;padding:28px;border-radius:12px;margin:28px 0;">
			<h3 style="margin-top:0;color:#fff;font-size:20px;"><?php echo esc_html( $atts['title'] ); ?></h3>
			<p style="color:#e2e8f0;margin-bottom:18px;">Chuyên viên Kênh BĐS sẽ gửi trực tiếp bộ tài liệu PDF nét cao & Bảng tính dòng tiền qua Zalo/Email trong 3 phút (Cam kết bảo mật 100%).</p>

			<?php if ( $submitted ) : ?>
				<div style="background:#1b8a4b;color:#fff;padding:16px;border-radius:8px;font-weight:600;">
					✔ Đăng ký thành công! Hệ thống đã ghi nhận yêu cầu và sẽ gửi bộ tài liệu cho bạn ngay lập tức.
				</div>
			<?php else : ?>
				<form method="post" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;">
					<?php wp_nonce_field( 'kbds_submit_lead', 'kbds_lead_nonce' ); ?>
					<input type="hidden" name="kbds_project" value="<?php echo esc_attr( $atts['project'] ); ?>" />
					<input type="text" name="kbds_name" required placeholder="Họ và tên của bạn *" style="padding:12px;border-radius:6px;border:none;color:#111;" />
					<input type="tel" name="kbds_phone" required placeholder="Số điện thoại / Zalo nhận file *" style="padding:12px;border-radius:6px;border:none;color:#111;" />
					<input type="text" name="kbds_demand" placeholder="Nhu cầu (VD: Căn 2PN, Giỏ hàng cắt lỗ...)" style="padding:12px;border-radius:6px;border:none;color:#111;" />
					<button type="submit" name="kbds_lead_submit" value="1" style="background:#d99b26;color:#fff;font-weight:700;border:none;padding:12px 20px;border-radius:6px;cursor:pointer;font-size:15px;">
						GỬI TÀI LIỆU & BẢNG GIÁ NGAY
					</button>
				</form>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Tự động hiển thị Bảng tổng quan, Giỏ hàng, Tính lãi vay và Form thu Lead trên trang Dự án (`du_an`)
	 */
	public static function auto_append_project_sections( $content ) {
		if ( ! is_singular( 'du_an' ) || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}

		$overview = has_shortcode( $content, 'kbds_project_overview' ) ? '' : self::shortcode_project_overview( array( 'id' => get_the_ID() ) );
		$listings = has_shortcode( $content, 'kbds_project_listings' ) ? '' : self::shortcode_project_listings( array( 'project_id' => get_the_ID() ) );
		$calc     = has_shortcode( $content, 'kbds_loan_calculator' ) ? '' : self::shortcode_loan_calculator();
		$form     = has_shortcode( $content, 'kbds_lead_form' ) ? '' : self::shortcode_lead_form( array( 'project' => get_the_title() ) );

		return $overview . $content . $listings . $calc . $form;
	}
}
