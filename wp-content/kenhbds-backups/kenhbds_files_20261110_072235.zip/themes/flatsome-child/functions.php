<?php
/**
 * Flatsome Child Theme Functions - Kênh Bất Động Sản (kenhbatdongsan.vn)
 *
 * Lưu ý quan trọng: Toàn bộ cấu trúc dữ liệu (Dự án, Giỏ hàng, Khách hàng, Backup)
 * được tách độc lập tại plugin `kenhbds-data-manager` để đảm bảo an toàn dữ liệu 100%
 * khi nâng cấp hoặc thay đổi giao diện.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Nạp CSS của Child Theme
 */
add_action( 'wp_enqueue_scripts', function() {
	wp_enqueue_style(
		'flatsome-child-style',
		get_stylesheet_directory_uri() . '/style.css',
		array( 'flatsome-main' ),
		wp_get_theme()->get( 'Version' )
	);
}, 20 );
